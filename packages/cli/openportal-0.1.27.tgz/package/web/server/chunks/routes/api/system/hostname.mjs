import { r as defineHandler } from "../../../nitro/nitro.mjs";
import { hostname } from "os";
var hostname_default = defineHandler(() => {
	return { hostname: hostname() };
});
export { hostname_default as default };
