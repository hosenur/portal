import { a as readBody, i as getRouterParam, r as defineHandler } from "../../../../../nitro/nitro.mjs";
import { getOpencodeClient } from "../../../lib/opencode-client.mjs";
var create_default = defineHandler(async (event) => {
	const port = Number(getRouterParam(event, "port"));
	if (!port || isNaN(port)) throw new Error("Invalid port");
	const body = await readBody(event);
	return (await getOpencodeClient(port).session.create({ body: {
		title: body?.title,
		parentID: body?.parentID
	} })).data;
});
export { create_default as default };
