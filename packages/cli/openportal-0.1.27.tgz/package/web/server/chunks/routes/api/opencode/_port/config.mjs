import { i as getRouterParam, r as defineHandler } from "../../../../nitro/nitro.mjs";
import { getOpencodeClient } from "../../lib/opencode-client.mjs";
var config_default = defineHandler(async (event) => {
	const port = Number(getRouterParam(event, "port"));
	if (!port || isNaN(port)) throw new Error("Invalid port");
	return (await getOpencodeClient(port).config.get()).data;
});
export { config_default as default };
