import { i as getRouterParam, r as defineHandler } from "../../../../../nitro/nitro.mjs";
import { getOpencodeClient } from "../../../lib/opencode-client.mjs";
var index_get_default = defineHandler(async (event) => {
	const port = Number(getRouterParam(event, "port"));
	const id = getRouterParam(event, "id");
	if (!port || isNaN(port)) throw new Error("Invalid port");
	if (!id) throw new Error("Session ID required");
	return (await getOpencodeClient(port).session.get({ path: { id } })).data;
});
export { index_get_default as default };
