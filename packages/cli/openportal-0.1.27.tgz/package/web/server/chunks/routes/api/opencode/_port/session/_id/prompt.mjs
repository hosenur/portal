import { a as readBody, i as getRouterParam, r as defineHandler } from "../../../../../../nitro/nitro.mjs";
import { getOpencodeClient } from "../../../../lib/opencode-client.mjs";
var prompt_default = defineHandler(async (event) => {
	const port = Number(getRouterParam(event, "port"));
	const id = getRouterParam(event, "id");
	if (!port || isNaN(port)) throw new Error("Invalid port");
	if (!id) throw new Error("Session ID required");
	const body = await readBody(event);
	if (!body?.text) throw new Error("Message text required");
	return (await getOpencodeClient(port).session.prompt({
		path: { id },
		body: {
			parts: [{
				type: "text",
				text: body.text
			}],
			model: body.model
		}
	})).data;
});
export { prompt_default as default };
