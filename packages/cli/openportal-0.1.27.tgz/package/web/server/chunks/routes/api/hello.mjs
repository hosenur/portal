import { r as defineHandler } from "../../nitro/nitro.mjs";
var hello_default = defineHandler(() => {
	return {
		message: "Hello from Nitro!",
		ok: true
	};
});
export { hello_default as default };
