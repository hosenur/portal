import { i as getRouterParam, r as defineHandler } from "../../../../nitro/nitro.mjs";
import { getOpencodeClient } from "../../lib/opencode-client.mjs";
var health_default = defineHandler(async (event) => {
	const port = Number(getRouterParam(event, "port"));
	if (!port || isNaN(port)) throw new Error("Invalid port");
	return {
		healthy: !!(await getOpencodeClient(port).config.get()).data,
		port
	};
});
export { health_default as default };
