import { r as defineHandler } from "../../nitro/nitro.mjs";
import { homedir } from "os";
import { join } from "path";
import { existsSync, readFileSync } from "fs";
var CONFIG_PATH = join(homedir(), ".portal.json");
function readConfig() {
	try {
		if (existsSync(CONFIG_PATH)) {
			const content = readFileSync(CONFIG_PATH, "utf-8");
			return JSON.parse(content);
		}
	} catch {}
	return { instances: [] };
}
function isProcessRunning(pid) {
	try {
		process.kill(pid, 0);
		return true;
	} catch {
		return false;
	}
}
var instances_default = defineHandler(async () => {
	const instances = readConfig().instances.filter((instance) => isProcessRunning(instance.pid)).map((instance) => ({
		id: instance.id,
		name: instance.name,
		directory: instance.directory,
		port: instance.port,
		hostname: instance.hostname,
		pid: instance.pid,
		startedAt: instance.startedAt,
		state: "running",
		status: `Running since ${new Date(instance.startedAt).toLocaleString()}`
	}));
	return {
		total: instances.length,
		instances
	};
});
export { instances_default as default };
