import { i as getRouterParam, r as defineHandler } from "../../../../../nitro/nitro.mjs";
import { getOpencodeClient } from "../../../lib/opencode-client.mjs";
var current_default = defineHandler(async (event) => {
	const port = Number(getRouterParam(event, "port"));
	if (!port || isNaN(port)) throw new Error("Invalid port");
	return (await getOpencodeClient(port).project.current()).data;
});
export { current_default as default };
